package com.example.articlereader;

import com.microsoft.cognitiveservices.speech.*;
import com.microsoft.cognitiveservices.speech.audio.*;

import java.util.concurrent.Future;

public class SpeechSynthesisService {

    private SpeechConfig speechConfig;

    public SpeechSynthesisService(String speechKey, String serviceRegion) {
        this.speechConfig = SpeechConfig.fromSubscription(speechKey, serviceRegion);
        // You can set the voice name here, e.g., "zh-CN-XiaoxiaoNeural"
        // For a list of supported voices, refer to Azure AI Speech documentation.
        this.speechConfig.setSpeechSynthesisVoiceName("zh-CN-XiaoxiaoNeural"); 
    }

    public byte[] synthesizeTextToAudio(String text) throws Exception {
        try (SpeechSynthesizer synthesizer = new SpeechSynthesizer(speechConfig, null)) {
            Future<SpeechSynthesisResult> task = synthesizer.SpeakTextAsync(text);
            SpeechSynthesisResult result = task.get();

            if (result.getReason() == ResultReason.SynthesizingAudioCompleted) {
                return result.getAudioData();
            } else if (result.getReason() == ResultReason.Canceled) {
                SpeechSynthesisCancellationDetails cancellation = SpeechSynthesisCancellationDetails.fromResult(result);
                throw new Exception("Speech synthesis canceled: " + cancellation.getReason() + ". Error details: " + cancellation.getErrorDetails());
            } else {
                throw new Exception("Speech synthesis failed with reason: " + result.getReason());
            }
        }
    }
}
