package com.example.articlereader;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import run.halo.app.plugin.BasePlugin;
import run.halo.app.plugin.PluginContext;


import java.util.Map;

/**
 * <p>Plugin main class to manage the lifecycle of the plugin.</p>
 * <p>This class must be public and have a public constructor.</p>
 * <p>Only one main class extending {@link BasePlugin} is allowed per plugin.</p>
 *
 * @author Manus
 * @since 1.0.0
 */
@Component
@RestController
@RequestMapping("/plugins/article-reader")
public class ArticleReaderPlugin extends BasePlugin {

    private SpeechSynthesisService speechSynthesisService;

    public ArticleReaderPlugin(PluginContext pluginContext) {
        super(pluginContext);
    }

    @Override
    public void start() {
        System.out.println("文章朗读插件启动成功！");



        // Initialize SpeechSynthesisService using settings
        initializeSpeechService();
    }

    @Override
    public void stop() {
        System.out.println("文章朗读插件停止！");
    }

    private void initializeSpeechService() {
        // Settings are typically managed via plugin.yaml and accessed through PluginContext
        // For this example, we'll assume settings are available via environment variables or a configuration file
        String speechKey = System.getenv("AZURE_SPEECH_KEY"); // Placeholder for actual configuration retrieval
        String serviceRegion = System.getenv("AZURE_SPEECH_REGION"); // Placeholder for actual configuration retrieval

        if (speechKey != null && !speechKey.isEmpty() && serviceRegion != null && !serviceRegion.isEmpty()) {
            this.speechSynthesisService = new SpeechSynthesisService(speechKey, serviceRegion);
            System.out.println("SpeechSynthesisService initialized successfully.");
        } else {
            System.err.println("Speech API Key or Service Region is not configured. Speech synthesis will not work.");
        }
    }

    @PostMapping(value = "/synthesize", consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public byte[] synthesizeArticle(@RequestBody String articleContent) throws Exception {
        if (speechSynthesisService == null) {
            throw new IllegalStateException("SpeechSynthesisService is not initialized. Please configure API Key and Region.");
        }
        return speechSynthesisService.synthesizeTextToAudio(articleContent);
    }

    // You might also want to add a method to update the service if settings change

}

