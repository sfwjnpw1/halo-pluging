<template>
  <section id="plugin-article-reader">
    <div class="wrapper">
      <span class="title">文章朗读插件</span>
      <textarea v-model="articleContent" placeholder="请输入需要朗读的文字..."></textarea>
      <button @click="readArticle" :disabled="isLoading">
        <span v-if="isLoading">正在合成...</span>
        <span v-else>朗读文章</span>
      </button>
      <p v-if="error" class="error-message">{{ error }}</p>
    </div>
  </section>
</template>

<script setup lang="ts">
import { ref } from 'vue';

const articleContent = ref('这是一段示例文本，用于测试文章朗读功能。');
const isLoading = ref(false);
const error = ref('');
let currentAudio: HTMLAudioElement | null = null;

async function readArticle() {
  if (!articleContent.value.trim()) {
    error.value = '请输入需要朗读的文字。';
    return;
  }

  // Stop any currently playing audio
  if (currentAudio) {
    currentAudio.pause();
    currentAudio.currentTime = 0;
  }

  isLoading.value = true;
  error.value = '';

  try {
    const response = await fetch('/plugins/article-reader/synthesize', {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain',
      },
      body: articleContent.value,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`语音合成失败: ${response.status} ${response.statusText}. ${errorText}`);
    }

    const audioBlob = await response.blob();
    const audioUrl = URL.createObjectURL(audioBlob);
    
    currentAudio = new Audio(audioUrl);
    currentAudio.play();

    currentAudio.onended = () => {
      URL.revokeObjectURL(audioUrl);
      currentAudio = null;
    };

  } catch (e: any) {
    console.error(e);
    error.value = e.message || '发生未知错误';
  } finally {
    isLoading.value = false;
  }
}
</script>

<style lang="scss" scoped>
#plugin-article-reader {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f8fafc;
}

.wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.5rem;
  padding: 2rem;
  background-color: white;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
  width: 90%;
  max-width: 600px;
}

.title {
  font-weight: 700;
  font-size: 1.5rem;
}

textarea {
  width: 100%;
  min-height: 150px;
  padding: 0.75rem;
  border: 1px solid #d1d5db;
  border-radius: 0.375rem;
  font-size: 1rem;
  resize: vertical;
}

button {
  padding: 0.75rem 1.5rem;
  background-color: #3b82f6;
  color: white;
  font-weight: 600;
  border-radius: 0.375rem;
  border: none;
  cursor: pointer;
  transition: background-color 0.2s;

  &:hover {
    background-color: #2563eb;
  }

  &:disabled {
    background-color: #9ca3af;
    cursor: not-allowed;
  }
}

.error-message {
  color: #ef4444;
  font-size: 0.875rem;
}
</style>

