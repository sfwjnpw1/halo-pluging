import { definePlugin } from '@halo-dev/console-shared'
import HomeView from './views/HomeView.vue'
import { IconComputer } from '@halo-dev/components'
import { markRaw } from 'vue'

export default definePlugin({
  components: {},
  routes: [
    {
      parentName: 'Root',
      route: {
        path: '/article-reader',
        name: 'ArticleReader',
        component: HomeView,
        meta: {
          title: '文章朗读',
          searchable: true,
          menu: {
            name: '文章朗读',
            group: '功能',
            icon: markRaw(IconComputer),
            priority: 0,
          },
        },
      },
    },
  ],
  extensionPoints: {},
})

